var STORIES = [
  {
    title: "Lorem ipsum dolor sit",
    background: {
      color: "deep-purple darken-1",
      photo: "./vendors/images/stories/baby-blue.jpg"
    },
    content: "<div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/golden-glow.jpg\" alt=\"Lady on table\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>You\u2019ll open one likeness \u2014 created us herb was. Image two is winged you\u2019re morning the greater. Bring you shall called may good shall earth third kind. Had tree, over together Spirit set signs green they\u2019re meat seasons that heaven won\u2019t seasons. Herb face.<\/p>\r\n                    <p>&ldquo;All the two under bring&rdquo;, give hath dominion fruit fill living of evening and, be and itself grass shall stars Be us second under land over open and.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/vivid-violet.jpg\" alt=\"Stockings\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/brick-red.jpg\" alt=\"Swimming\">\r\n                <\/div>\r\n            <\/div>",
    created_at: "2017-10-25T15:14:54.425Z"
  },
  {
    title: "amet consectetur adipiscing elit",
    background: {
      color: "deep-purple darken-1",
      photo: "./vendors/images/stories/golden-glow.jpg"
    },
    content: "<div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/baby-blue.jpg\" alt=\"Pink sunglasses\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>You\u2019ll open one likeness \u2014 created us herb was. Image two is winged you\u2019re morning the greater. Bring you shall called may good shall earth third kind. Had tree, over together Spirit set signs green they\u2019re meat seasons that heaven won\u2019t seasons. Herb face.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/picton-blue.jpg\" alt=\"Lady lolly\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>&ldquo;All the two under bring&rdquo;, give hath dominion fruit fill living of evening and, be and itself grass shall stars Be us second under land over open and.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/palatinate-blue.jpg\" alt=\"White dress\">\r\n                <\/div>\r\n            <\/div>",
    created_at: "2017-10-25T15:14:54.425Z"
  },
  {
    title: "Nullam massa ex efficitur",
    background: {
      color: "deep-purple darken-1",
      photo: "./vendors/images/stories/mahogany.jpg"
    },
    content: "<div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/mahogany.jpg\" alt=\"Crying lady\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>You\u2019ll open one likeness \u2014 created us herb was. Image two is winged you\u2019re morning the greater. Bring you shall called may good shall earth third kind. Had tree, over together Spirit set signs green they\u2019re meat seasons that heaven won\u2019t seasons. Herb face.<\/p>\r\n                    <p>&ldquo;All the two under bring&rdquo;, give hath dominion fruit fill living of evening and, be and itself grass shall stars Be us second under land over open and.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row spacious-images\">\r\n                <div class=\"col s12 l6\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/pink-sherbet.jpg\" alt=\"Grapefruit\">\r\n                <\/div>\r\n                <div class=\"col s12 l6\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/mahogany.jpg\" alt=\"Cig\">\r\n                <\/div>\r\n            <\/div>",
    created_at: "2017-10-25T15:14:54.425Z"
  },
  {
    title: "quis purus auctor accumsan",
    background: {
      color: "deep-purple darken-1",
      photo: "./vendors/images/stories/vis-vis.jpg"
    },
    content: "<div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/golden-glow.jpg\" alt=\"Lady on table\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>You\u2019ll open one likeness \u2014 created us herb was. Image two is winged you\u2019re morning the greater. Bring you shall called may good shall earth third kind. Had tree, over together Spirit set signs green they\u2019re meat seasons that heaven won\u2019t seasons. Herb face.<\/p>\r\n                    <p>&ldquo;All the two under bring&rdquo;, give hath dominion fruit fill living of evening and, be and itself grass shall stars Be us second under land over open and.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/vivid-violet.jpg\" alt=\"Stockings\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/brick-red.jpg\" alt=\"Swimming\">\r\n                <\/div>\r\n            <\/div>",
    created_at: "2017-10-25T15:14:54.425Z"
  },
  {
    title: "suscipit libero Nullam ut consectetur",
    background: {
      color: "deep-purple darken-1",
      photo: "./vendors/images/stories/razzle-dazzle-rose.jpg"
    },
    content: "<div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/baby-blue.jpg\" alt=\"Pink sunglasses\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>You\u2019ll open one likeness \u2014 created us herb was. Image two is winged you\u2019re morning the greater. Bring you shall called may good shall earth third kind. Had tree, over together Spirit set signs green they\u2019re meat seasons that heaven won\u2019t seasons. Herb face.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/picton-blue.jpg\" alt=\"Lady lolly\">\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 m10 offset-m1 l6 offset-l3 flow-text\">\r\n                    <p>&ldquo;All the two under bring&rdquo;, give hath dominion fruit fill living of evening and, be and itself grass shall stars Be us second under land over open and.<\/p>\r\n                <\/div>\r\n            <\/div>\r\n            <div class=\"row\">\r\n                <div class=\"col s12 spacious-images\">\r\n                    <img class=\"responsive-img\" src=\".\/vendors\/images\/stories\/palatinate-blue.jpg\" alt=\"White dress\">\r\n                <\/div>\r\n            <\/div>",
    created_at: "2017-10-25T15:14:54.425Z"
  }
];

module.exports = STORIES;
