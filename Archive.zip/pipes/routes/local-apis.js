var request = require('request');

module.exports = function(app){
  var instagram_api = require('./local-apis/instagram-api')(app);
}
